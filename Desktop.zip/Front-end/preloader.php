<!--<script type="text/javascript">
/*jQuery(document).ready(function($) {
  $(window).load(function() {
    setTimeout(function() {
      $('#preloader').fadeOut('slow', function() {});
    }, 2000);

  });
});*/
</script>-->
<style type="text/css">
	#preloader {
		position: fixed;
		left: 0;
		top: 0;
		z-index: 100000;
		width: 100%;
		height: 100%;
		overflow: visible;
		background: #fff url('images/loading2.gif') no-repeat center center;
	}
</style>
<div id="preloader"></div>