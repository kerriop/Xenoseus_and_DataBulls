<nav role="navigation" class="navbar navbar-default navbar-top navbar-fixed-top">
	<div class="navbar-header">
		<a href="javascript:void(0);" class="navbar-brand">
			<div class="brand-logo">Xenoseus</div>
			<div class="brand-logo-collapsed">X</div>
		</a>
	</div>
	<div class="nav-wrapper">
		<ul class="nav navbar-nav">
			<li>
				<a href="javascript:void(0);" data-toggle="aside">
				<em class="fa fa-align-left"></em>
				</a>
			</li>
			<li>
				<a href="javascript:void(0);" data-toggle="navbar-search">
				<em class="fa fa-search"></em>
				</a>
			</li>
		</ul>
	</div>
	<form action="javascript:void(0);" id="search" class="navbar-form">
		<div class="form-group has-feedback">
			<input type="text" placeholder="Введите запрос и нажмите enter.." class="form-control" name="request">
			<div data-toggle="navbar-search-dismiss" class="fa fa-times form-control-feedback"></div>
		</div>
		<button type="submit" class="hidden btn btn-default">Найти</button>
	</form>
</nav>