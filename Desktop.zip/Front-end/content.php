<div class="row">
	<div class="col">
		<div class="panel panel-default">
			<div class="panel-wrapper collapse in" style="height: auto;">
				<div class="table-responsive">
					<table id="mainResult" class="table table-striped table-bordered table-hover">
						<thead>
							
						</thead>
						<tbody>
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<!--
<tr>
							<td>Bootstrap 5.x</td>
							<td>
								<span data-bar-color="danger" class="inlinesparkline">
									 <canvas width="34" height="18" style="display: inline-block; vertical-align: top; width: 34px; height: 18px;"></canvas>
								</span>
							</td>
							<td>
								<div class="label label-danger">Canceled</div>
							</td>
							<td class="text-center">
								<div class="btn-group">
									 <a href="javascript:void(0);" data-toggle="dropdown" class="btn btn-default btn-xs dropdown-toggle">
									 <em class="fa fa-angle-down"></em>Action</a>
									 <ul class="dropdown-menu pull-right text-left">
										<li><a href="javascript:void(0);">Cancel</a></li>
										<li><a href="javascript:void(0);">Delay</a></li>
										<li><a href="javascript:void(0);">Re Plan </a></li>
										<li><a href="javascript:void(0);">Invoke meeting</a></li>
									 </ul>
								</div>
							</td>
							</tr>
							<tr>
							<td>Web Engine</td>
							<td>
								<span data-bar-color="success" class="inlinesparkline">
									 <canvas width="34" height="18" style="display: inline-block; vertical-align: top; width: 34px; height: 18px;"></canvas>
								</span>
							</td>
							<td>
								<div class="label label-success">Complete</div>
							</td>
							<td class="text-center">
								<div class="btn-group">
									 <a href="javascript:void(0);" data-toggle="dropdown" class="btn btn-default btn-xs dropdown-toggle">
									 <em class="fa fa-angle-down"></em>Action</a>
									 <ul class="dropdown-menu pull-right text-left">
										<li><a href="javascript:void(0);">Cancel</a></li>
										<li><a href="javascript:void(0);">Delay</a></li>
										<li><a href="javascript:void(0);">Re Plan </a></li>
										<li><a href="javascript:void(0);">Invoke meeting</a></li>
									 </ul>
								</div>
							</td>
							</tr>
							<tr>
							<td>Nullam sit amet</td>
							<td>
								<span data-bar-color="warning" class="inlinesparkline">
									 <canvas width="34" height="18" style="display: inline-block; vertical-align: top; width: 34px; height: 18px;"></canvas>
								</span>
							</td>
							<td>
								<div class="label label-warning">Delayed</div>
							</td>
							<td class="text-center">
								<div class="btn-group">
									 <a href="javascript:void(0);" data-toggle="dropdown" class="btn btn-default btn-xs dropdown-toggle">
									 <em class="fa fa-angle-down"></em>Action</a>
									 <ul class="dropdown-menu pull-right text-left">
										<li><a href="javascript:void(0);">Cancel</a></li>
										<li><a href="javascript:void(0);">Delay</a></li>
										<li><a href="javascript:void(0);">Re Plan </a></li>
										<li><a href="javascript:void(0);">Invoke meeting</a></li>
									 </ul>
								</div>
							</td>
							</tr>
							-->