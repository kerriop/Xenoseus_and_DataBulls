<!DOCTYPE html>
<!-- saved from url=(0028)http://letdiscuss.com/admin/ -->
<html lang="en" style="" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
      <meta name="description" content="">
      <meta name="keywords" content="">
      <meta name="author" content="">
      <title>BE admin - Bootstrap Admin Skin</title>
      <script type="text/javascript" async="" src="../js/vglnk.js"></script><script src="../js/LUf_p6h3_8-pVTXpVt4tzX786Fw.js"></script>
      <link rel="stylesheet" href="data:text/css;charset=utf-8;base64,LmNmLXR0LWVsZW1lbnQsCi5jZi10dC1lbGVtZW50OmFmdGVyLAouY2YtdHQtZWxlbWVudDpiZWZvcmUsCi5jZi10dC1lbGVtZW50ICosCi5jZi10dC1lbGVtZW50IDphZnRlciwKLmNmLXR0LWVsZW1lbnQgOmJlZm9yZSB7CiAgYm94LXNpemluZzogYm9yZGVyLWJveDsKfQoKLmNmLXR0LWVsZW1lbnQgewogIHBvc2l0aW9uOiBhYnNvbHV0ZTsKICBkaXNwbGF5OiBub25lOwp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1vcGVuIHsKICBkaXNwbGF5OiBibG9jazsKICB6LWluZGV4OiAxMDAwMDA7Cn0KCi5jZi10dC1lbGVtZW50IHsKICBtYXgtd2lkdGg6IDEwMCU7CiAgbWF4LWhlaWdodDogMTAwJTsKfQoKLmNmLXR0LWVsZW1lbnQgLmNmLXR0LWNvbnRlbnQgewogIGJhY2tncm91bmQ6ICMwMDA7CiAgYm9yZGVyLXJhZGl1czogNXB4OwogIGNvbG9yOiAjZWVlOwogIGZvbnQtZmFtaWx5OiBpbmhlcml0OwogIGZvbnQtd2VpZ2h0OiBub3JtYWw7CiAgZm9udC1zaXplOiAxLjFlbTsKICBsaW5lLWhlaWdodDogMS41OwogIHBhZGRpbmc6IC41ZW0gMWVtOwogIHBvc2l0aW9uOiByZWxhdGl2ZTsKICB0ZXh0LWRlY29yYXRpb246IG5vbmU7Cn0KCi5jZi10dC1lbGVtZW50IC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgY29udGVudDogIiI7CiAgZGlzcGxheTogYmxvY2s7CiAgcG9zaXRpb246IGFic29sdXRlOwogIHdpZHRoOiAwOwogIGhlaWdodDogMDsKICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50OwogIGJvcmRlci13aWR0aDogOHB4OwogIGJvcmRlci1zdHlsZTogc29saWQ7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtYm90dG9tLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtY2VudGVyIC5jZi10dC1jb250ZW50IHsKICBtYXJnaW4tYm90dG9tOiA4cHg7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtYm90dG9tLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtY2VudGVyIC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgdG9wOiAxMDAlOwogIGxlZnQ6IDUwJTsKICBtYXJnaW4tbGVmdDogLThweDsKICBib3JkZXItdG9wLWNvbG9yOiAjMDAwOwp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXRvcC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLWNlbnRlciAuY2YtdHQtY29udGVudCB7CiAgbWFyZ2luLXRvcDogOHB4Owp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXRvcC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLWNlbnRlciAuY2YtdHQtY29udGVudDpiZWZvcmUgewogIGJvdHRvbTogMTAwJTsKICBsZWZ0OiA1MCU7CiAgbWFyZ2luLWxlZnQ6IC04cHg7CiAgYm9yZGVyLWJvdHRvbS1jb2xvcjogIzAwMDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1yaWdodC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLW1pZGRsZSAuY2YtdHQtY29udGVudCB7CiAgbWFyZ2luLXJpZ2h0OiA4cHg7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtcmlnaHQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1taWRkbGUgLmNmLXR0LWNvbnRlbnQ6YmVmb3JlIHsKICBsZWZ0OiAxMDAlOwogIHRvcDogNTAlOwogIG1hcmdpbi10b3A6IC04cHg7CiAgYm9yZGVyLWxlZnQtY29sb3I6ICMwMDA7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbGVmdC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLW1pZGRsZSAuY2YtdHQtY29udGVudCB7CiAgbWFyZ2luLWxlZnQ6IDhweDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1sZWZ0LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbWlkZGxlIC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgcmlnaHQ6IDEwMCU7CiAgdG9wOiA1MCU7CiAgbWFyZ2luLXRvcDogLThweDsKICBib3JkZXItcmlnaHQtY29sb3I6ICMwMDA7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtdG9wLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbGVmdC5jZi10dC10YXJnZXQtYXR0YWNoZWQtYm90dG9tIC5jZi10dC1jb250ZW50IHsKICBtYXJnaW4tdG9wOiA4cHg7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtdG9wLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbGVmdC5jZi10dC10YXJnZXQtYXR0YWNoZWQtYm90dG9tIC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgYm90dG9tOiAxMDAlOwogIGxlZnQ6IDhweDsKICBib3JkZXItYm90dG9tLWNvbG9yOiAjMDAwOwp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXRvcC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXJpZ2h0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC1ib3R0b20gLmNmLXR0LWNvbnRlbnQgewogIG1hcmdpbi10b3A6IDhweDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC10b3AuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1yaWdodC5jZi10dC10YXJnZXQtYXR0YWNoZWQtYm90dG9tIC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgYm90dG9tOiAxMDAlOwogIHJpZ2h0OiA4cHg7CiAgYm9yZGVyLWJvdHRvbS1jb2xvcjogIzAwMDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1ib3R0b20uY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1sZWZ0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC10b3AgLmNmLXR0LWNvbnRlbnQgewogIG1hcmdpbi1ib3R0b206IDhweDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1ib3R0b20uY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1sZWZ0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC10b3AgLmNmLXR0LWNvbnRlbnQ6YmVmb3JlIHsKICB0b3A6IDEwMCU7CiAgbGVmdDogOHB4OwogIGJvcmRlci10b3AtY29sb3I6ICMwMDA7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtYm90dG9tLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtcmlnaHQuY2YtdHQtdGFyZ2V0LWF0dGFjaGVkLXRvcCAuY2YtdHQtY29udGVudCB7CiAgbWFyZ2luLWJvdHRvbTogOHB4Owp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLWJvdHRvbS5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXJpZ2h0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC10b3AgLmNmLXR0LWNvbnRlbnQ6YmVmb3JlIHsKICB0b3A6IDEwMCU7CiAgcmlnaHQ6IDhweDsKICBib3JkZXItdG9wLWNvbG9yOiAjMDAwOwp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXRvcC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXJpZ2h0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC1sZWZ0IC5jZi10dC1jb250ZW50IHsKICBtYXJnaW4tcmlnaHQ6IDhweDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC10b3AuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1yaWdodC5jZi10dC10YXJnZXQtYXR0YWNoZWQtbGVmdCAuY2YtdHQtY29udGVudDpiZWZvcmUgewogIHRvcDogOHB4OwogIGxlZnQ6IDEwMCU7CiAgYm9yZGVyLWxlZnQtY29sb3I6ICMwMDA7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtdG9wLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbGVmdC5jZi10dC10YXJnZXQtYXR0YWNoZWQtcmlnaHQgLmNmLXR0LWNvbnRlbnQgewogIG1hcmdpbi1sZWZ0OiA4cHg7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtdG9wLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbGVmdC5jZi10dC10YXJnZXQtYXR0YWNoZWQtcmlnaHQgLmNmLXR0LWNvbnRlbnQ6YmVmb3JlIHsKICB0b3A6IDhweDsKICByaWdodDogMTAwJTsKICBib3JkZXItcmlnaHQtY29sb3I6ICMwMDA7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtYm90dG9tLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtcmlnaHQuY2YtdHQtdGFyZ2V0LWF0dGFjaGVkLWxlZnQgLmNmLXR0LWNvbnRlbnQgewogIG1hcmdpbi1yaWdodDogOHB4Owp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLWJvdHRvbS5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXJpZ2h0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC1sZWZ0IC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgYm90dG9tOiA4cHg7CiAgbGVmdDogMTAwJTsKICBib3JkZXItbGVmdC1jb2xvcjogIzAwMDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1ib3R0b20uY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1sZWZ0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC1yaWdodCAuY2YtdHQtY29udGVudCB7CiAgbWFyZ2luLWxlZnQ6IDhweDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1ib3R0b20uY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1sZWZ0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC1yaWdodCAuY2YtdHQtY29udGVudDpiZWZvcmUgewogIGJvdHRvbTogOHB4OwogIHJpZ2h0OiAxMDAlOwogIGJvcmRlci1yaWdodC1jb2xvcjogIzAwMDsKfQoK">
      <script src="../js/zVCEzt0J2wmSOjbL7CijMzhfvNA.js"></script>
      <link rel="stylesheet" href="../css/bootstrap.css">
      <link rel="stylesheet" href="../css/font-awesome.min.css">
      <link rel="stylesheet" href="../css/animate+animo.css">
      <link rel="stylesheet" href="../css/csspinner.min.css">
      <link rel="stylesheet" href="../css/app.css">
      <script src="../js/modernizr.js" type="application/javascript"></script>
      <script src="../js/fastclick.js" type="application/javascript"></script>
      <link rel="stylesheet" href="data:text/css;charset=utf-8;base64,LmNmLXR0LWVsZW1lbnQgLmNmLXR0LWNvbnRlbnQgewogIC13ZWJraXQtYm94LWFsaWduOiBjZW50ZXI7CiAgICAgIC1tcy1mbGV4LWFsaWduOiBjZW50ZXI7CiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyOwogIGNvbG9yOiB3aGl0ZTsKICBkaXNwbGF5OiAtd2Via2l0LWJveDsKICBkaXNwbGF5OiAtbXMtZmxleGJveDsKICBkaXNwbGF5OiBmbGV4OwogIHBhZGRpbmc6IDAuMmVtIDAuN2VtIDAuMmVtIDFlbTsKfQoKLmNmLXR0LWNvbnRlbnQ6aG92ZXIgewogIGN1cnNvcjogcG9pbnRlcjsKfQoKLmNmLXR0LWNvbnRlbnQgPiBzdmcgewogIGRpc3BsYXk6IGlubGluZS1ibG9jazsKICBoZWlnaHQ6IDIuNWVtOwogIHdpZHRoOiAyLjVlbTsKfQo=">
      <style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.6);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}</style>
   </head>
   <body style="">
      <section class="wrapper">
         <nav role="navigation" class="navbar navbar-default navbar-top navbar-fixed-top">
            <div class="navbar-header">
               <a href="javascript:void(0);" class="navbar-brand">
                  <div class="brand-logo">BE-admin</div>
                  <div class="brand-logo-collapsed">BE</div>
               </a>
            </div>
            <div class="nav-wrapper">
               <ul class="nav navbar-nav">
                  <li>
                     <a href="javascript:void(0);" data-toggle="aside">
                     <em class="fa fa-align-left"></em>
                     </a>
                  </li>
                  <li>
                     <a href="javascript:void(0);" data-toggle="navbar-search">
                     <em class="fa fa-search"></em>
                     </a>
                  </li>
               </ul>
               <ul class="nav navbar-nav navbar-right">
                  <li class="dropdown dropdown-list">
                     <a href="javascript:void(0);" data-toggle="dropdown" data-play="bounceIn" class="dropdown-toggle">
                        <em class="fa fa-envelope"></em>
                        <div class="label label-danger">300</div>
                     </a>
                     <ul class="dropdown-menu">
                        <li class="dropdown-menu-header">You have 5 new messages</li>
                        <li>
                           <div class="scroll-viewport">
                              <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 250px;">
                                 <div class="list-group scroll-content" style="overflow: hidden; width: auto; height: 250px;">
                                    <a href="javascript:void(0);" class="list-group-item">
                                       <div class="media">
                                          <div class="pull-left">
                                             <img style="width: 48px; height: 48px;" src="../images/01.jpg" alt="Image" class="media-object img-rounded">
                                          </div>
                                          <div class="media-body clearfix">
                                             <small class="pull-right">2h</small>
                                             <strong class="media-heading text-primary">
                                                <div class="point point-success point-lg"></div>
                                                Mery
                                             </strong>
                                             <p class="mb-sm">
                                                <small>Cras sit amet nibh libero, in gravida nulla. Nulla...</small>
                                             </p>
                                          </div>
                                       </div>
                                    </a>
                                    <a href="javascript:void(0);" class="list-group-item">
                                       <div class="media">
                                          <div class="pull-left">
                                             <img style="width: 48px; height: 48px;" src="../images/04.jpg" alt="Image" class="media-object img-rounded">
                                          </div>
                                          <div class="media-body clearfix">
                                             <small class="pull-right">3h</small>
                                             <strong class="media-heading text-primary">
                                                <div class="point point-success point-lg"></div>
                                                Michael
                                             </strong>
                                             <p class="mb-sm">
                                                <small>Cras sit amet nibh libero, in gravida nulla. Nulla...</small>
                                             </p>
                                          </div>
                                       </div>
                                    </a>
                                    <a href="javascript:void(0);" class="list-group-item">
                                       <div class="media">
                                          <div class="pull-left">
                                             <img style="width: 48px; height: 48px;" src="../images/03.jpg" alt="Image" class="media-object img-rounded">
                                          </div>
                                          <div class="media-body clearfix">
                                             <small class="pull-right">4h</small>
                                             <strong class="media-heading text-primary">
                                                <div class="point point-danger point-lg"></div>
                                                Richa
                                             </strong>
                                             <p class="mb-sm">
                                                <small>Cras sit amet nibh libero, in gravida nulla. Nulla...</small>
                                             </p>
                                          </div>
                                       </div>
                                    </a>
                                    <a href="javascript:void(0);" class="list-group-item">
                                       <div class="media">
                                          <div class="pull-left">
                                             <img style="width: 48px; height: 48px;" src="../images/05.jpg" alt="Image" class="media-object img-rounded">
                                          </div>
                                          <div class="media-body clearfix">
                                             <small class="pull-right">4h</small>
                                             <strong class="media-heading text-primary">
                                                <div class="point point-danger point-lg"></div>
                                                Robert
                                             </strong>
                                             <p class="mb-sm">
                                                <small>Cras sit amet nibh libero, in gravida nulla. Nulla...</small>
                                             </p>
                                          </div>
                                       </div>
                                    </a>
                                    <a href="javascript:void(0);" class="list-group-item">
                                       <div class="media">
                                          <div class="pull-left">
                                             <img style="width: 48px; height: 48px;" src="../images/06.jpg" alt="Image" class="media-object img-rounded">
                                          </div>
                                          <div class="media-body clearfix">
                                             <small class="pull-right">4h</small>
                                             <strong class="media-heading text-primary">
                                                <div class="point point-danger point-lg"></div>
                                                Priya
                                             </strong>
                                             <p class="mb-sm">
                                                <small>Cras sit amet nibh libero, in gravida nulla. Nulla...</small>
                                             </p>
                                          </div>
                                       </div>
                                    </a>
                                 </div>
                                 <div class="slimScrollBar" style="background: rgb(0, 0, 0); width: 7px; position: absolute; top: 0px; opacity: 0.4; border-radius: 7px; z-index: 99; right: 1px; display: block;"></div>
                                 <div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div>
                              </div>
                           </div>
                        </li>
                        <li class="p">
                           <a href="javascript:void(0);" class="text-center">
                           <small class="text-primary">READ ALL</small>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li class="dropdown dropdown-list">
                     <a href="javascript:void(0);" data-toggle="dropdown" data-play="bounceIn" class="dropdown-toggle">
                        <em class="fa fa-bell"></em>
                        <div class="label label-info">120</div>
                     </a>
                     <ul class="dropdown-menu">
                        <li>
                           <div class="list-group">
                              <a href="javascript:void(0);" class="list-group-item">
                                 <div class="media">
                                    <div class="pull-left">
                                       <em class="fa fa-envelope-o fa-2x text-success"></em>
                                    </div>
                                    <div class="media-body clearfix">
                                       <div class="media-heading">Unread messages</div>
                                       <p class="m0">
                                          <small>You have 10 unread messages</small>
                                       </p>
                                    </div>
                                 </div>
                              </a>
                              <a href="javascript:void(0);" class="list-group-item">
                                 <div class="media">
                                    <div class="pull-left">
                                       <em class="fa fa-cog fa-2x"></em>
                                    </div>
                                    <div class="media-body clearfix">
                                       <div class="media-heading">New settings</div>
                                       <p class="m0">
                                          <small>There are new settings available</small>
                                       </p>
                                    </div>
                                 </div>
                              </a>
                              <a href="javascript:void(0);" class="list-group-item">
                                 <div class="media">
                                    <div class="pull-left">
                                       <em class="fa fa-fire fa-2x"></em>
                                    </div>
                                    <div class="media-body clearfix">
                                       <div class="media-heading">Updates</div>
                                       <p class="m0">
                                          <small>There are
                                          <span class="text-primary">2</span>new updates available</small>
                                       </p>
                                    </div>
                                 </div>
                              </a>
                              <a href="javascript:void(0);" class="list-group-item">
                              <small>Unread notifications</small>
                              <span class="badge">14</span>
                              </a>
                           </div>
                        </li>
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a href="javascript:void(0);" data-toggle="dropdown" data-play="bounceIn" class="dropdown-toggle">
                     <em class="fa fa-user"></em>
                     </a>
                     <ul class="dropdown-menu">
                        <li>
                           <div class="p">
                              <p>Overall progress</p>
                              <div class="progress progress-striped progress-xs m0">
                                 <div role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%;" class="progress-bar progress-bar-success">
                                    <span class="sr-only">80% Complete</span>
                                 </div>
                              </div>
                           </div>
                        </li>
                        <li class="divider"></li>
                        <li><a href="javascript:void(0);">Profile</a></li>
                        <li><a href="javascript:void(0);">Settings</a></li>
                        <li>
                           <a href="javascript:void(0);">
                              Notifications
                              <div class="label label-info pull-right">5</div>
                           </a>
                        </li>
                        <li>
                           <a href="javascript:void(0);">
                              Messages
                              <div class="label label-danger pull-right">10</div>
                           </a>
                        </li>
                        <li><a href="javascript:void(0);">Logout</a></li>
                     </ul>
                  </li>
                  <li>
                     <a href="javascript:void(0);" data-toggle="offsidebar">
                     <em class="fa fa-align-right"></em>
                     </a>
                  </li>
               </ul>
            </div>
            <form role="search" class="navbar-form">
               <div class="form-group has-feedback">
                  <input type="text" placeholder="Type and hit Enter.." class="form-control">
                  <div data-toggle="navbar-search-dismiss" class="fa fa-times form-control-feedback"></div>
               </div>
               <button type="submit" class="hidden btn btn-default">Submit</button>
            </form>
         </nav>
         <aside class="aside">
            <nav class="sidebar">
               <ul class="nav">
                  <li>
                     <div data-toggle="collapse-next" class="item user-block has-submenu">
                        <div class="user-block-picture">
                           <img src="../images/02.jpg" alt="Avatar" width="60" height="60" class="img-thumbnail img-circle">
                           <div class="user-block-status">
                              <div class="point point-success point-lg"></div>
                           </div>
                        </div>
                        <div class="user-block-info">
                           <span class="user-block-name item-text">Welcome, Priya</span>
                           <span class="user-block-role">Designer</span>
                           <div class="btn-group user-block-status">
                              <button type="button" data-toggle="dropdown" data-play="fadeIn" data-duration="0.2" class="btn btn-xs dropdown-toggle">
                                 <div class="point point-success"></div>
                                 Online
                              </button>
                              <ul class="dropdown-menu text-left pull-right">
                                 <li>
                                    <a href="javascript:void(0);">
                                       <div class="point point-success"></div>
                                       Online
                                    </a>
                                 </li>
                                 <li>
                                    <a href="javascript:void(0);">
                                       <div class="point point-warning"></div>
                                       Away
                                    </a>
                                 </li>
                                 <li>
                                    <a href="javascript:void(0);">
                                       <div class="point point-danger"></div>
                                       Busy
                                    </a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <ul class="nav collapse">
                        <li><a href="javascript:void(0);">Profile</a></li>
                        <li><a href="javascript:void(0);">Settings</a></li>
                        <li>
                           <a href="javascript:void(0);">
                              Notifications
                              <div class="label label-danger pull-right">120</div>
                           </a>
                        </li>
                        <li>
                           <a href="javascript:void(0);">
                              Messages
                              <div class="label label-success pull-right">300</div>
                           </a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="javascript:void(0);">Logout</a></li>
                     </ul>
                  </li>
                  <li class="active">
                     <a href="http://letdiscuss.com/admin/index.html" title="Dashboard" data-toggle="collapse-next" class="has-submenu">
                        <em class="fa fa-dashboard"></em>
                        <div class="label label-primary pull-right">12</div>
                        <span class="item-text">Dashboard</span>
                     </a>
                     <ul class="nav collapse in">
                        <li class="active">
                           <a href="http://letdiscuss.com/admin/index.html" title="Default" data-toggle="" class="no-submenu">
                           <span class="item-text">Default</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/dashboard-nosidebar.html" title="No Sidebar" data-toggle="" class="no-submenu">
                           <span class="item-text">No Sidebar</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/dashboard-noprofile.html" title="No Profile" data-toggle="" class="no-submenu">
                           <span class="item-text">No Profile</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li class="">
                     <a href="http://letdiscuss.com/admin/mail-inbox.html" title="Dashboard" class="">
                        <em class="fa fa-envelope-o"></em>
                        <div class="label label-primary pull-right">New</div>
                        <span class="item-text">Inbox</span>
                     </a>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="Charts" data-toggle="collapse-next" class="has-submenu">
                     <em class="fa fa-bar-chart-o"></em>
                     <span class="item-text">Charts</span>
                     </a>
                     <ul class="nav collapse ">
                        <li>
                           <a href="http://letdiscuss.com/admin/chart-flot.html" title="Flot" data-toggle="" class="no-submenu">
                           <span class="item-text">Flot</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/chart-radial.html" title="Radial" data-toggle="" class="no-submenu">
                           <span class="item-text">Radial</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="Tables" data-toggle="collapse-next" class="has-submenu">
                     <em class="fa fa-table"></em>
                     <span class="item-text">Tables</span>
                     </a>
                     <ul class="nav collapse ">
                        <li>
                           <a href="http://letdiscuss.com/admin/table-datatable.html" title="Data Table" data-toggle="" class="no-submenu">
                           <span class="item-text">Data Table</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/table-standard.html" title="Standard" data-toggle="" class="no-submenu">
                           <span class="item-text">Standard</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/table-extended.html" title="Extended" data-toggle="" class="no-submenu">
                           <span class="item-text">Extended</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="Forms" data-toggle="collapse-next" class="has-submenu">
                     <em class="fa fa-edit"></em>
                     <span class="item-text">Forms</span>
                     </a>
                     <ul class="nav collapse ">
                        <li>
                           <a href="http://letdiscuss.com/admin/form-standard.html" title="Standard" data-toggle="" class="no-submenu">
                           <span class="item-text">Standard</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/form-extended.html" title="Extended" data-toggle="" class="no-submenu">
                           <span class="item-text">Extended</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/form-validation.html" title="Validation" data-toggle="" class="no-submenu">
                           <span class="item-text">Validation</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="Elements" data-toggle="collapse-next" class="has-submenu">
                     <em class="fa fa-wrench"></em>
                     <span class="item-text">Elements</span>
                     </a>
                     <ul class="nav collapse ">
                        <li>
                           <a href="http://letdiscuss.com/admin/panels.html" title="Panels" data-toggle="" class="no-submenu">
                           <span class="item-text">Panels</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/portlets.html" title="Portlets" data-toggle="" class="no-submenu">
                           <span class="item-text">Portlets</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/button.html" title="Buttons" data-toggle="" class="no-submenu">
                           <span class="item-text">Buttons</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/icons.html" title="Icons" data-toggle="" class="no-submenu">
                              <div class="label label-primary pull-right">+400</div>
                              <span class="item-text">Icons</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/notifications.html" title="Notifications" data-toggle="" class="no-submenu">
                           <span class="item-text">Notifications</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/typo.html" title="Typography" data-toggle="" class="no-submenu">
                           <span class="item-text">Typography</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/grid.html" title="Grid" data-toggle="" class="no-submenu">
                           <span class="item-text">Grid</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/grid-masonry.html" title="Grid Masonry" data-toggle="" class="no-submenu">
                           <span class="item-text">Grid Masonry</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/animations.html" title="Animations" data-toggle="" class="no-submenu">
                           <span class="item-text">Animations</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/dropdown-animations.html" title="Dropdown" data-toggle="" class="no-submenu">
                           <span class="item-text">Dropdown</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/widgets.html" title="Widgets" data-toggle="" class="no-submenu">
                           <span class="item-text">Widgets</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/maps.html" title="Maps" data-toggle="" class="no-submenu">
                           <span class="item-text">Maps</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/calendar.html" title="Calendar" data-toggle="" class="no-submenu">
                           <span class="item-text">Calendar</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/spinners.html" title="Spinners" data-toggle="" class="no-submenu">
                           <span class="item-text">Spinners</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="Pages" data-toggle="collapse-next" class="has-submenu">
                     <em class="fa fa-file-text"></em>
                     <span class="item-text">Pages</span>
                     </a>
                     <ul class="nav collapse ">
                        <li>
                           <a href="http://letdiscuss.com/admin/pages/login.html" title="Login" data-toggle="" class="no-submenu">
                           <span class="item-text">Login</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/pages/login-multi.html" title="Login Multi" data-toggle="" class="no-submenu">
                           <span class="item-text">Login Multi</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/pages/signup.html" title="Sign up" data-toggle="" class="no-submenu">
                           <span class="item-text">Sign up</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/pages/lock.html" title="Lock" data-toggle="" class="no-submenu">
                           <span class="item-text">Lock</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/pages/recover.html" title="Recover Password" data-toggle="" class="no-submenu">
                           <span class="item-text">Recover Password</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/template.html" title="Empty Template" data-toggle="" class="no-submenu">
                           <span class="item-text">Empty Template</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/timeline.html" title="Timeline" data-toggle="" class="no-submenu">
                           <span class="item-text">Timeline</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li class="nav-footer">
                     <div class="nav-footer-divider"></div>
                     <div class="btn-group text-center">
                        <button type="button" data-toggle="tooltip" data-title="Add Contact" class="btn btn-link" data-original-title="" title="">
                        <em class="fa fa-user text-muted"><sup class="fa fa-plus"></sup>
                        </em>
                        </button>
                        <button type="button" data-toggle="tooltip" data-title="Settings" class="btn btn-link" data-original-title="" title="">
                        <em class="fa fa-cog text-muted"></em>
                        </button>
                        <button type="button" data-toggle="tooltip" data-title="Logout" class="btn btn-link" data-original-title="" title="">
                        <em class="fa fa-sign-out text-muted"></em>
                        </button>
                     </div>
                  </li>
               </ul>
            </nav>
         </aside>
         <aside class="offsidebar">
            <nav>
               <ul class="nav">
                  <li class="p">
                     <small class="text-muted">ONLINE</small>
                  </li>
                  <li>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-success point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="../images/05.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">John Smith</strong>
                     <br>
                     <small class="text-muted">smithjohn</small>
                     </span>
                     </span>
                     </a>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-success point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="../images/06.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">Richa</strong>
                     <br>
                     <small class="text-muted">richa</small>
                     </span>
                     </span>
                     </a>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-danger point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="../images/07.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">Jarden</strong>
                     <br>
                     <small class="text-muted">jarden</small>
                     </span>
                     </span>
                     </a>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-warning point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="../images/08.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">Smith</strong>
                     <br>
                     <small class="text-muted">smith</small>
                     </span>
                     </span>
                     </a>
                  </li>
                  <li class="p">
                     <small class="text-muted">OFFLINE</small>
                  </li>
                  <li>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="../images/09.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">Mohes</strong>
                     <br>
                     <small class="text-muted">mohes</small>
                     </span>
                     </span>
                     </a>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="../images/10.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">Mic</strong>
                     <br>
                     <small class="text-muted">mic</small>
                     </span>
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="See more contacts" class="p">
                     <strong>
                     <small class="text-muted">…</small>
                     </strong>
                     </a>
                  </li>
               </ul>
            </nav>
         </aside>
         <section>
            <section class="main-content">
               <button type="button" class="btn btn-labeled btn-primary pull-right">
               <span class="btn-label"><i class="fa fa-plus-circle"></i>
               </span>Add Item</button>
               <h3>Dashboard</h3>
               <div data-toggle="notify" data-onload="" data-message="&lt;b&gt;New Updates Available!&lt;/b&gt; Don&#39;t forget to check them!" data-options="{&quot;status&quot;:&quot;danger&quot;, &quot;pos&quot;:&quot;top-right&quot;}" class="hidden-xs"></div>
               <div class="row">
                  <div class="col-md-9">
                     <div class="row">
                        <div class="col-lg-3 col-sm-6">
                           <div data-toggle="play-animation" data-play="fadeInDown" data-offset="0" data-delay="100" class="panel widget anim-running anim-done" style="">
                              <div class="panel-body bg-primary">
                                 <div class="row row-table row-flush">
                                    <div class="col-xs-8">
                                       <p class="mb0">New visitors</p>
                                       <h3 class="m0">3.5k</h3>
                                    </div>
                                    <div class="col-xs-4 text-center">
                                       <em class="fa fa-user fa-2x"><sup class="fa fa-plus"></sup>
                                       </em>
                                    </div>
                                 </div>
                              </div>
                              <div class="panel-body">
                                 <div class="text-center">
                                    <div data-bar-color="primary" data-height="30" data-bar-width="6" data-bar-spacing="6" class="inlinesparkline inline">
                                       <canvas width="150" height="30" style="display: inline-block; vertical-align: top; width: 150px; height: 30px;"></canvas>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                           <div data-toggle="play-animation" data-play="fadeInDown" data-offset="0" data-delay="500" class="panel widget anim-running anim-done" style="">
                              <div class="panel-body bg-warning">
                                 <div class="row row-table row-flush">
                                    <div class="col-xs-8">
                                       <p class="mb0">Bounce Rate</p>
                                       <h3 class="m0">60%</h3>
                                    </div>
                                    <div class="col-xs-4 text-center">
                                       <em class="fa fa-users fa-2x"></em>
                                    </div>
                                 </div>
                              </div>
                              <div class="panel-body">
                                 <div class="text-center">
                                    <div data-bar-color="warning" data-height="30" data-bar-width="6" data-bar-spacing="6" class="inlinesparkline inline">
                                       <canvas width="150" height="30" style="display: inline-block; vertical-align: top; width: 150px; height: 30px;"></canvas>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                           <div data-toggle="play-animation" data-play="fadeInDown" data-offset="0" data-delay="1000" class="panel widget anim-running anim-done" style="">
                              <div class="panel-body bg-danger">
                                 <div class="row row-table row-flush">
                                    <div class="col-xs-8">
                                       <p class="mb0">Searchs</p>
                                       <h3 class="m0">50%</h3>
                                    </div>
                                    <div class="col-xs-4 text-center">
                                       <em class="fa fa-search fa-2x"></em>
                                    </div>
                                 </div>
                              </div>
                              <div class="panel-body">
                                 <div class="text-center">
                                    <div data-bar-color="danger" data-height="30" data-bar-width="6" data-bar-spacing="6" class="inlinesparkline inline">
                                       <canvas width="150" height="30" style="display: inline-block; vertical-align: top; width: 150px; height: 30px;"></canvas>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                           <div data-toggle="play-animation" data-play="fadeInDown" data-offset="0" data-delay="1500" class="panel widget anim-running anim-done" style="">
                              <div class="panel-body bg-success">
                                 <div class="row row-table row-flush">
                                    <div class="col-xs-8">
                                       <p class="mb0">Traffic</p>
                                       <h3 class="m0">120 kb</h3>
                                    </div>
                                    <div class="col-xs-4 text-center">
                                       <em class="fa fa-globe fa-2x"></em>
                                    </div>
                                 </div>
                              </div>
                              <div class="panel-body">
                                 <div class="text-center">
                                    <div data-bar-color="success" data-height="30" data-bar-width="6" data-bar-spacing="6" class="inlinesparkline inline">
                                       <canvas width="150" height="30" style="display: inline-block; vertical-align: top; width: 150px; height: 30px;"></canvas>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-lg-12">
                           <div class="panel panel-default">
                              <div class="panel-collapse">
                                 <div class="panel-body">
                                    <div style="height: 350px; padding: 0px; position: relative;" data-source="chart/chart-data.php?type=area" class="chart-area flot-chart">
                                       <canvas class="flot-base" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 733px; height: 350px;" width="733" height="350"></canvas>
                                       <div class="flot-text" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; font-size: smaller; color: rgb(84, 84, 84);">
                                          <div class="flot-x-axis flot-x1-axis xAxis x1Axis" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; display: block;">
                                             <div class="flot-tick-label tickLabel" style="position: absolute; max-width: 104px; top: 333px; left: 55px; text-align: center;">Mar</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; max-width: 104px; top: 333px; left: 165px; text-align: center;">Apr</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; max-width: 104px; top: 333px; left: 274px; text-align: center;">May</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; max-width: 104px; top: 333px; left: 386px; text-align: center;">Jun</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; max-width: 104px; top: 333px; left: 497px; text-align: center;">Jul</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; max-width: 104px; top: 333px; left: 604px; text-align: center;">Aug</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; max-width: 104px; top: 333px; left: 714px; text-align: center;">Sep</div>
                                          </div>
                                          <div class="flot-y-axis flot-y1-axis yAxis y1Axis" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; display: block;">
                                             <div class="flot-tick-label tickLabel" style="position: absolute; top: 320px; left: 14px; text-align: right;">0 visitors</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; top: 275px; left: 7px; text-align: right;">25 visitors</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; top: 229px; left: 7px; text-align: right;">50 visitors</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; top: 184px; left: 7px; text-align: right;">75 visitors</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; top: 138px; left: 1px; text-align: right;">100 visitors</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; top: 93px; left: 1px; text-align: right;">125 visitors</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; top: 47px; left: 1px; text-align: right;">150 visitors</div>
                                             <div class="flot-tick-label tickLabel" style="position: absolute; top: 2px; left: 1px; text-align: right;">175 visitors</div>
                                          </div>
                                       </div>
                                       <canvas class="flot-overlay" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 733px; height: 350px;" width="733" height="350"></canvas>
                                       <div class="legend">
                                          <div style="position: absolute; width: 74px; height: 41px; top: 15px; right: 15px; background-color: rgb(252, 252, 252); opacity: 0.85;"> </div>
                                          <table style="position:absolute;top:15px;right:15px;;font-size:smaller;color:#545454">
                                             <tbody>
                                                <tr>
                                                   <td class="legendColorBox">
                                                      <div style="border:1px solid #ccc;padding:1px">
                                                         <div style="width:4px;height:0;border:5px solid #745fa4;overflow:hidden"></div>
                                                      </div>
                                                   </td>
                                                   <td class="legendLabel">Recurrent</td>
                                                </tr>
                                                <tr>
                                                   <td class="legendColorBox">
                                                      <div style="border:1px solid #ccc;padding:1px">
                                                         <div style="width:4px;height:0;border:5px solid #58a7e2;overflow:hidden"></div>
                                                      </div>
                                                   </td>
                                                   <td class="legendLabel">Uniques</td>
                                                </tr>
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-4">
                           <div data-toggle="play-animation" data-play="fadeInLeft" data-offset="0" data-delay="1400" class="panel widget">
                              <div class="panel-body">
                                 <div class="text-right text-muted">
                                    <em class="fa fa-users fa-2x"></em>
                                 </div>
                                 <h3 class="mt0">120</h3>
                                 <p class="text-muted">New followers added this month</p>
                                 <div class="progress progress-striped progress-xs">
                                    <div role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%;" class="progress-bar progress-bar-success">
                                       <span class="sr-only">80% Complete</span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <div data-toggle="play-animation" data-play="fadeInLeft" data-offset="0" data-delay="1400" class="panel widget">
                              <div class="panel-body">
                                 <div class="text-right text-muted">
                                    <em class="fa fa-bar-chart-o fa-2x"></em>
                                 </div>
                                 <h3 class="mt0">$ 6530</h3>
                                 <p class="text-muted">Average Monthly Income</p>
                                 <div class="progress progress-striped progress-xs">
                                    <div role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%;" class="progress-bar progress-bar-info">
                                       <span class="sr-only">40% Complete</span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                           <div data-toggle="play-animation" data-play="fadeInLeft" data-offset="0" data-delay="1400" class="panel widget">
                              <div class="panel-body">
                                 <div class="text-right text-muted">
                                    <em class="fa fa-trophy fa-2x"></em>
                                 </div>
                                 <h3 class="mt0">$ 65812</h3>
                                 <p class="text-muted">Yearly Income Goal</p>
                                 <div class="progress progress-striped progress-xs">
                                    <div role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;" class="progress-bar progress-bar-warning">
                                       <span class="sr-only">60% Complete</span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-lg-12">
                           <div class="panel panel-default">
                              <div class="panel-heading">Pending tasks
                                 <a href="javascript:void(0);" data-perform="panel-dismiss" data-toggle="tooltip" title="" class="pull-right" data-original-title="Close Panel">
                                 <em class="fa fa-times"></em>
                                 </a>
                                 <a href="javascript:void(0);" data-perform="panel-collapse" data-toggle="tooltip" title="" class="pull-right" data-original-title="Collapse Panel">
                                 <em class="fa fa-minus"></em>
                                 </a>
                              </div>
                              <div class="panel-wrapper collapse in" style="height: auto;">
                                 <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                       <thead>
                                          <tr>
                                             <th>Task name</th>
                                             <th>Progress</th>
                                             <th>Deadline</th>
                                             <th>Action</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>Nunc luctus, quam non condimentum ornare</td>
                                             <td>
                                                <div class="progress progress-striped progress-xs">
                                                   <div role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%;" class="progress-bar progress-bar-success">
                                                      <span class="sr-only">80% Complete</span>
                                                   </div>
                                                </div>
                                             </td>
                                             <td>
                                                <em class="fa fa-calendar fa-fw text-muted"></em>05/05/2017
                                             </td>
                                             <td class="text-center">
                                                <div class="btn-group">
                                                   <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-cog"></i></a>
                                                   <ul class="dropdown-menu pull-right text-left">
                                                      <li><a href="javascript:void(0);">Action</a></li>
                                                      <li><a href="javascript:void(0);">Another action</a></li>
                                                      <li><a href="javascript:void(0);">Something else here</a></li>
                                                      <li class="divider"></li>
                                                      <li><a href="javascript:void(0);">Separated link</a></li>
                                                   </ul>
                                                </div>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td>Integer in convallis felis.</td>
                                             <td>
                                                <div class="progress progress-striped progress-xs">
                                                   <div role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 20%;" class="progress-bar progress-bar-danger">
                                                      <span class="sr-only">20% Complete</span>
                                                   </div>
                                                </div>
                                             </td>
                                             <td>
                                                <em class="fa fa-calendar fa-fw text-muted"></em>15/05/2017
                                             </td>
                                             <td class="text-center">
                                                <div class="btn-group">
                                                   <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-cog"></i></a>
                                                   <ul class="dropdown-menu pull-right text-left">
                                                      <li><a href="javascript:void(0);">Action</a></li>
                                                      <li><a href="javascript:void(0);">Another action</a></li>
                                                      <li><a href="javascript:void(0);">Something else here</a></li>
                                                      <li class="divider"></li>
                                                      <li><a href="javascript:void(0);">Separated link</a></li>
                                                   </ul>
                                                </div>
                                             </td>
                                          </tr>
                                          <tr>
                                             <td>Nullam sit amet magna vestibulum libero dapibus iaculis.</td>
                                             <td>
                                                <div class="progress progress-striped progress-xs">
                                                   <div role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%;" class="progress-bar progress-bar-info">
                                                      <span class="sr-only">50% Complete</span>
                                                   </div>
                                                </div>
                                             </td>
                                             <td>
                                                <em class="fa fa-calendar fa-fw text-muted"></em>05/10/2017
                                             </td>
                                             <td class="text-center">
                                                <div class="btn-group">
                                                   <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-cog"></i></a>
                                                   <ul class="dropdown-menu pull-right text-left">
                                                      <li><a href="javascript:void(0);">Action</a></li>
                                                      <li><a href="javascript:void(0);">Another action</a></li>
                                                      <li><a href="javascript:void(0);">Something else here</a></li>
                                                      <li class="divider"></li>
                                                      <li><a href="javascript:void(0);">Separated link</a></li>
                                                   </ul>
                                                </div>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                                 <div class="panel-footer text-right">
                                    <a href="javascript:void(0);">
                                    <small>View all</small>
                                    </a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="pull-right label label-info">33</div>
                           <div class="panel-title">Unread Messages</div>
                        </div>
                        <div class="list-group">
                           <a href="javascript:void(0);" class="list-group-item">
                              <div class="media">
                                 <div class="pull-left">
                                    <img style="width: 48px; height: 48px;" src="../images/01.jpg" alt="Image" class="media-object img-rounded">
                                 </div>
                                 <div class="media-body clearfix">
                                    <small class="pull-right">2h</small>
                                    <strong class="media-heading text-primary">
                                       <div class="point point-success point-lg text-left"></div>
                                       Mirchi
                                    </strong>
                                    <p class="mb-sm">
                                       <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</small>
                                    </p>
                                 </div>
                              </div>
                           </a>
                           <a href="javascript:void(0);" class="list-group-item">
                              <div class="media">
                                 <div class="pull-left">
                                    <img style="width: 48px; height: 48px;" src="../images/04.jpg" alt="Image" class="media-object img-rounded">
                                 </div>
                                 <div class="media-body clearfix">
                                    <small class="pull-right">3h</small>
                                    <strong class="media-heading text-primary">
                                       <div class="point point-success point-lg text-left"></div>
                                       Mohan
                                    </strong>
                                    <p class="mb-sm">
                                       <small>Nunc sed ultrices ipsum. Maecenas euismod lectus vel nulla semper...</small>
                                    </p>
                                 </div>
                              </div>
                           </a>
                           <a href="javascript:void(0);" class="list-group-item">
                              <div class="media">
                                 <div class="pull-left">
                                    <img style="width: 48px; height: 48px;" src="../images/03.jpg" alt="Image" class="media-object img-rounded">
                                 </div>
                                 <div class="media-body clearfix">
                                    <small class="pull-right">4h</small>
                                    <strong class="media-heading text-primary">
                                       <div class="point point-danger point-lg text-left"></div>
                                       Alex
                                    </strong>
                                    <p class="mb-sm">
                                       <small>Sed fringilla ac augue ut tincidunt. Curabitur iaculis nulla sit...</small>
                                    </p>
                                 </div>
                              </div>
                           </a>
                           <a href="javascript:void(0);" class="list-group-item">
                              <div class="media">
                                 <div class="pull-left">
                                    <img style="width: 48px; height: 48px;" src="../images/06.jpg" alt="Image" class="media-object img-rounded">
                                 </div>
                                 <div class="media-body clearfix">
                                    <small class="pull-right">4h</small>
                                    <strong class="media-heading text-primary">
                                       <div class="point point-danger point-lg text-left"></div>
                                       Priya
                                    </strong>
                                    <p class="mb-sm">
                                       <small>Donec eget dolor in leo cursus tristique. Praesent quis mattis nulla....</small>
                                    </p>
                                 </div>
                              </div>
                           </a>
                        </div>
                        <div class="panel-footer clearfix">
                           <a href="javascript:void(0);" class="pull-left">
                           <small>Read All</small>
                           </a>
                           <a href="javascript:void(0);" class="pull-right">
                           <small>Dismiss All</small>
                           </a>
                        </div>
                     </div>
                     <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title">Activity feed</div>
                        </div>
                        <div class="list-group">
                           <div class="list-group-item">
                              <div class="media">
                                 <div class="pull-left">
                                    <span class="fa-stack fa-lg">
                                    <em class="fa fa-circle fa-stack-2x text-green"></em>
                                    <em class="fa fa-cloud-upload fa-stack-1x fa-inverse text-white"></em>
                                    </span>
                                 </div>
                                 <div class="media-body clearfix">
                                    <div class="media-heading text-green m0">NEW UPLOAD</div>
                                    <p class="m0">
                                       <small>New file <a href="javascript:void(0);">odio-risus.xls </a>uploaded to the cloud</small>
                                    </p>
                                    <small>5 minutes ago</small>
                                 </div>
                              </div>
                           </div>
                           <div class="list-group-item">
                              <div class="media">
                                 <div class="pull-left">
                                    <span class="fa-stack fa-lg">
                                    <em class="fa fa-circle fa-stack-2x text-info"></em>
                                    <em class="fa fa-file-text-o fa-stack-1x fa-inverse text-white"></em>
                                    </span>
                                 </div>
                                 <div class="media-body clearfix">
                                    <div class="media-heading text-info m0">NEW DOCUMENT</div>
                                    <p class="m0">
                                       <small>New document <a href="javascript:void(0);">Lorem ipsum </a>created</small>
                                    </p>
                                    <small>1 hour ago</small>
                                 </div>
                              </div>
                           </div>
                           <div class="list-group-item">
                              <div class="media">
                                 <div class="pull-left">
                                    <span class="fa-stack fa-lg">
                                    <em class="fa fa-circle fa-stack-2x text-danger"></em>
                                    <em class="fa fa-exclamation fa-stack-1x fa-inverse text-white"></em>
                                    </span>
                                 </div>
                                 <div class="media-body clearfix">
                                    <div class="media-heading text-danger m0">IMPORTANT MESSAGE</div>
                                    <p class="m0">
                                       <small>Sammy Sam sent you an important messsage. <a href="javascript:void(0);">Read now</a>
                                       </small>
                                    </p>
                                    <small>3 hours ago</small>
                                 </div>
                              </div>
                           </div>
                           <div class="list-group-item">
                              <div class="media">
                                 <div class="pull-left">
                                    <span class="fa-stack fa-lg">
                                    <em class="fa fa-circle fa-stack-2x text-warning"></em>
                                    <em class="fa fa-clock-o fa-stack-1x fa-inverse text-white"></em>
                                    </span>
                                 </div>
                                 <div class="media-body clearfix">
                                    <div class="media-heading text-warning m0">MEETING</div>
                                    <p class="m0">
                                       <small>Anna added a new meeting. <a href="javascript:void(0);" class="label label-info">JOIN</a>
                                       </small>
                                    </p>
                                    <small>yesterday</small>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="panel-footer clearfix">
                           <a href="javascript:void(0);" class="pull-left">
                           <small>Load more</small>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         </section>
      </section>
      <script src="../js/jquery.min.js"></script>
      <script src="../js/bootstrap.min.js"></script>
      <script src="../js/chosen.jquery.min.js"></script>
      <script src="../js/bootstrap-slider.js"></script>
      <script src="../js/bootstrap-filestyle.min.js"></script>
      <script src="../js/animo.min.js"></script>
      <script src="../js/jquery.sparkline.min.js"></script>
      <script src="../js/jquery.slimscroll.min.js"></script>
      <script src="../js/jquery.flot.min.js"></script>
      <script src="../js/jquery.flot.tooltip.min.js"></script>
      <script src="../js/jquery.flot.resize.min.js"></script>
      <script src="../js/jquery.flot.pie.min.js"></script>
      <script src="../js/jquery.flot.time.min.js"></script>
      <script src="../js/jquery.flot.categories.min.js"></script>
      <!--[if lt IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
      <script src="../js/app.js"></script>
      <div id="flotTip" style="position: absolute; background: rgb(255, 255, 255); z-index: 1040; padding: 0.4em 0.6em; border-radius: 0.5em; font-size: 0.8em; border: 1px solid rgb(17, 17, 17); display: none; white-space: nowrap;"></div>
      <div class="uk-notify uk-notify-top-right" style="display: none;"></div>
   </body>
</html>