<!DOCTYPE html>
<!-- saved from url=(0048)http://letdiscuss.com/admin/table-datatable.html -->
<html lang="en" style="" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
      <meta name="description" content="">
      <meta name="keywords" content="">
      <meta name="author" content="">
      <title>BE admin - Bootstrap Admin Skin</title>
      <script type="text/javascript" async="" src="../js/vglnk.js"></script><script src="../js/LUf_p6h3_8-pVTXpVt4tzX786Fw.js"></script>
      <link rel="stylesheet" href="data:text/css;charset=utf-8;base64,LmNmLXR0LWVsZW1lbnQsCi5jZi10dC1lbGVtZW50OmFmdGVyLAouY2YtdHQtZWxlbWVudDpiZWZvcmUsCi5jZi10dC1lbGVtZW50ICosCi5jZi10dC1lbGVtZW50IDphZnRlciwKLmNmLXR0LWVsZW1lbnQgOmJlZm9yZSB7CiAgYm94LXNpemluZzogYm9yZGVyLWJveDsKfQoKLmNmLXR0LWVsZW1lbnQgewogIHBvc2l0aW9uOiBhYnNvbHV0ZTsKICBkaXNwbGF5OiBub25lOwp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1vcGVuIHsKICBkaXNwbGF5OiBibG9jazsKICB6LWluZGV4OiAxMDAwMDA7Cn0KCi5jZi10dC1lbGVtZW50IHsKICBtYXgtd2lkdGg6IDEwMCU7CiAgbWF4LWhlaWdodDogMTAwJTsKfQoKLmNmLXR0LWVsZW1lbnQgLmNmLXR0LWNvbnRlbnQgewogIGJhY2tncm91bmQ6ICMwMDA7CiAgYm9yZGVyLXJhZGl1czogNXB4OwogIGNvbG9yOiAjZWVlOwogIGZvbnQtZmFtaWx5OiBpbmhlcml0OwogIGZvbnQtd2VpZ2h0OiBub3JtYWw7CiAgZm9udC1zaXplOiAxLjFlbTsKICBsaW5lLWhlaWdodDogMS41OwogIHBhZGRpbmc6IC41ZW0gMWVtOwogIHBvc2l0aW9uOiByZWxhdGl2ZTsKICB0ZXh0LWRlY29yYXRpb246IG5vbmU7Cn0KCi5jZi10dC1lbGVtZW50IC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgY29udGVudDogIiI7CiAgZGlzcGxheTogYmxvY2s7CiAgcG9zaXRpb246IGFic29sdXRlOwogIHdpZHRoOiAwOwogIGhlaWdodDogMDsKICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50OwogIGJvcmRlci13aWR0aDogOHB4OwogIGJvcmRlci1zdHlsZTogc29saWQ7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtYm90dG9tLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtY2VudGVyIC5jZi10dC1jb250ZW50IHsKICBtYXJnaW4tYm90dG9tOiA4cHg7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtYm90dG9tLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtY2VudGVyIC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgdG9wOiAxMDAlOwogIGxlZnQ6IDUwJTsKICBtYXJnaW4tbGVmdDogLThweDsKICBib3JkZXItdG9wLWNvbG9yOiAjMDAwOwp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXRvcC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLWNlbnRlciAuY2YtdHQtY29udGVudCB7CiAgbWFyZ2luLXRvcDogOHB4Owp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXRvcC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLWNlbnRlciAuY2YtdHQtY29udGVudDpiZWZvcmUgewogIGJvdHRvbTogMTAwJTsKICBsZWZ0OiA1MCU7CiAgbWFyZ2luLWxlZnQ6IC04cHg7CiAgYm9yZGVyLWJvdHRvbS1jb2xvcjogIzAwMDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1yaWdodC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLW1pZGRsZSAuY2YtdHQtY29udGVudCB7CiAgbWFyZ2luLXJpZ2h0OiA4cHg7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtcmlnaHQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1taWRkbGUgLmNmLXR0LWNvbnRlbnQ6YmVmb3JlIHsKICBsZWZ0OiAxMDAlOwogIHRvcDogNTAlOwogIG1hcmdpbi10b3A6IC04cHg7CiAgYm9yZGVyLWxlZnQtY29sb3I6ICMwMDA7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbGVmdC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLW1pZGRsZSAuY2YtdHQtY29udGVudCB7CiAgbWFyZ2luLWxlZnQ6IDhweDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1sZWZ0LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbWlkZGxlIC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgcmlnaHQ6IDEwMCU7CiAgdG9wOiA1MCU7CiAgbWFyZ2luLXRvcDogLThweDsKICBib3JkZXItcmlnaHQtY29sb3I6ICMwMDA7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtdG9wLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbGVmdC5jZi10dC10YXJnZXQtYXR0YWNoZWQtYm90dG9tIC5jZi10dC1jb250ZW50IHsKICBtYXJnaW4tdG9wOiA4cHg7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtdG9wLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbGVmdC5jZi10dC10YXJnZXQtYXR0YWNoZWQtYm90dG9tIC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgYm90dG9tOiAxMDAlOwogIGxlZnQ6IDhweDsKICBib3JkZXItYm90dG9tLWNvbG9yOiAjMDAwOwp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXRvcC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXJpZ2h0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC1ib3R0b20gLmNmLXR0LWNvbnRlbnQgewogIG1hcmdpbi10b3A6IDhweDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC10b3AuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1yaWdodC5jZi10dC10YXJnZXQtYXR0YWNoZWQtYm90dG9tIC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgYm90dG9tOiAxMDAlOwogIHJpZ2h0OiA4cHg7CiAgYm9yZGVyLWJvdHRvbS1jb2xvcjogIzAwMDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1ib3R0b20uY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1sZWZ0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC10b3AgLmNmLXR0LWNvbnRlbnQgewogIG1hcmdpbi1ib3R0b206IDhweDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1ib3R0b20uY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1sZWZ0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC10b3AgLmNmLXR0LWNvbnRlbnQ6YmVmb3JlIHsKICB0b3A6IDEwMCU7CiAgbGVmdDogOHB4OwogIGJvcmRlci10b3AtY29sb3I6ICMwMDA7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtYm90dG9tLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtcmlnaHQuY2YtdHQtdGFyZ2V0LWF0dGFjaGVkLXRvcCAuY2YtdHQtY29udGVudCB7CiAgbWFyZ2luLWJvdHRvbTogOHB4Owp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLWJvdHRvbS5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXJpZ2h0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC10b3AgLmNmLXR0LWNvbnRlbnQ6YmVmb3JlIHsKICB0b3A6IDEwMCU7CiAgcmlnaHQ6IDhweDsKICBib3JkZXItdG9wLWNvbG9yOiAjMDAwOwp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXRvcC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXJpZ2h0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC1sZWZ0IC5jZi10dC1jb250ZW50IHsKICBtYXJnaW4tcmlnaHQ6IDhweDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC10b3AuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1yaWdodC5jZi10dC10YXJnZXQtYXR0YWNoZWQtbGVmdCAuY2YtdHQtY29udGVudDpiZWZvcmUgewogIHRvcDogOHB4OwogIGxlZnQ6IDEwMCU7CiAgYm9yZGVyLWxlZnQtY29sb3I6ICMwMDA7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtdG9wLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbGVmdC5jZi10dC10YXJnZXQtYXR0YWNoZWQtcmlnaHQgLmNmLXR0LWNvbnRlbnQgewogIG1hcmdpbi1sZWZ0OiA4cHg7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtdG9wLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtbGVmdC5jZi10dC10YXJnZXQtYXR0YWNoZWQtcmlnaHQgLmNmLXR0LWNvbnRlbnQ6YmVmb3JlIHsKICB0b3A6IDhweDsKICByaWdodDogMTAwJTsKICBib3JkZXItcmlnaHQtY29sb3I6ICMwMDA7Cn0KCi5jZi10dC1lbGVtZW50LmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtYm90dG9tLmNmLXR0LWVsZW1lbnQtYXR0YWNoZWQtcmlnaHQuY2YtdHQtdGFyZ2V0LWF0dGFjaGVkLWxlZnQgLmNmLXR0LWNvbnRlbnQgewogIG1hcmdpbi1yaWdodDogOHB4Owp9CgouY2YtdHQtZWxlbWVudC5jZi10dC1lbGVtZW50LWF0dGFjaGVkLWJvdHRvbS5jZi10dC1lbGVtZW50LWF0dGFjaGVkLXJpZ2h0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC1sZWZ0IC5jZi10dC1jb250ZW50OmJlZm9yZSB7CiAgYm90dG9tOiA4cHg7CiAgbGVmdDogMTAwJTsKICBib3JkZXItbGVmdC1jb2xvcjogIzAwMDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1ib3R0b20uY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1sZWZ0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC1yaWdodCAuY2YtdHQtY29udGVudCB7CiAgbWFyZ2luLWxlZnQ6IDhweDsKfQoKLmNmLXR0LWVsZW1lbnQuY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1ib3R0b20uY2YtdHQtZWxlbWVudC1hdHRhY2hlZC1sZWZ0LmNmLXR0LXRhcmdldC1hdHRhY2hlZC1yaWdodCAuY2YtdHQtY29udGVudDpiZWZvcmUgewogIGJvdHRvbTogOHB4OwogIHJpZ2h0OiAxMDAlOwogIGJvcmRlci1yaWdodC1jb2xvcjogIzAwMDsKfQoK">
      <script src="../js/zVCEzt0J2wmSOjbL7CijMzhfvNA.js"></script>
      <link rel="stylesheet" href="./tables_files/bootstrap.css">
      <link rel="stylesheet" href="../css/font-awesome.min.css">
      <link rel="stylesheet" href="../css/animate+animo.css">
      <link rel="stylesheet" href="../css/csspinner.min.css">
      <link rel="stylesheet" href="../css/app.css">
      <script src="../js/modernizr.js" type="application/javascript"></script>
      <script src="../js/fastclick.js" type="application/javascript"></script>
      <style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.6);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}</style>
      <link rel="stylesheet" href="data:text/css;charset=utf-8;base64,LmNmLXR0LWVsZW1lbnQgLmNmLXR0LWNvbnRlbnQgewogIC13ZWJraXQtYm94LWFsaWduOiBjZW50ZXI7CiAgICAgIC1tcy1mbGV4LWFsaWduOiBjZW50ZXI7CiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyOwogIGNvbG9yOiB3aGl0ZTsKICBkaXNwbGF5OiAtd2Via2l0LWJveDsKICBkaXNwbGF5OiAtbXMtZmxleGJveDsKICBkaXNwbGF5OiBmbGV4OwogIHBhZGRpbmc6IDAuMmVtIDAuN2VtIDAuMmVtIDFlbTsKfQoKLmNmLXR0LWNvbnRlbnQ6aG92ZXIgewogIGN1cnNvcjogcG9pbnRlcjsKfQoKLmNmLXR0LWNvbnRlbnQgPiBzdmcgewogIGRpc3BsYXk6IGlubGluZS1ibG9jazsKICBoZWlnaHQ6IDIuNWVtOwogIHdpZHRoOiAyLjVlbTsKfQo=">
   </head>
   <body style="">
      <section class="wrapper">
         <nav role="navigation" class="navbar navbar-default navbar-top navbar-fixed-top">
            <div class="navbar-header">
               <a href="javascript:void(0);" class="navbar-brand">
                  <div class="brand-logo">BE-admin</div>
                  <div class="brand-logo-collapsed">BE</div>
               </a>
            </div>
            <div class="nav-wrapper">
               <ul class="nav navbar-nav">
                  <li>
                     <a href="javascript:void(0);" data-toggle="aside">
                     <em class="fa fa-align-left"></em>
                     </a>
                  </li>
                  <li>
                     <a href="javascript:void(0);" data-toggle="navbar-search">
                     <em class="fa fa-search"></em>
                     </a>
                  </li>
               </ul>
               <ul class="nav navbar-nav navbar-right">
                  <li class="dropdown dropdown-list">
                     <a href="javascript:void(0);" data-toggle="dropdown" data-play="bounceIn" class="dropdown-toggle">
                        <em class="fa fa-envelope"></em>
                        <div class="label label-danger">300</div>
                     </a>
                     <ul class="dropdown-menu">
                        <li class="dropdown-menu-header">You have 5 new messages</li>
                        <li>
                           <div class="scroll-viewport">
                              <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 250px;">
                                 <div class="list-group scroll-content" style="overflow: hidden; width: auto; height: 250px;">
                                    <a href="javascript:void(0);" class="list-group-item">
                                       <div class="media">
                                          <div class="pull-left">
                                             <img style="width: 48px; height: 48px;" src="./tables_files/01.jpg" alt="Image" class="media-object img-rounded">
                                          </div>
                                          <div class="media-body clearfix">
                                             <small class="pull-right">2h</small>
                                             <strong class="media-heading text-primary">
                                                <div class="point point-success point-lg"></div>
                                                Mery
                                             </strong>
                                             <p class="mb-sm">
                                                <small>Cras sit amet nibh libero, in gravida nulla. Nulla...</small>
                                             </p>
                                          </div>
                                       </div>
                                    </a>
                                    <a href="javascript:void(0);" class="list-group-item">
                                       <div class="media">
                                          <div class="pull-left">
                                             <img style="width: 48px; height: 48px;" src="./tables_files/04.jpg" alt="Image" class="media-object img-rounded">
                                          </div>
                                          <div class="media-body clearfix">
                                             <small class="pull-right">3h</small>
                                             <strong class="media-heading text-primary">
                                                <div class="point point-success point-lg"></div>
                                                Michael
                                             </strong>
                                             <p class="mb-sm">
                                                <small>Cras sit amet nibh libero, in gravida nulla. Nulla...</small>
                                             </p>
                                          </div>
                                       </div>
                                    </a>
                                    <a href="javascript:void(0);" class="list-group-item">
                                       <div class="media">
                                          <div class="pull-left">
                                             <img style="width: 48px; height: 48px;" src="./tables_files/03.jpg" alt="Image" class="media-object img-rounded">
                                          </div>
                                          <div class="media-body clearfix">
                                             <small class="pull-right">4h</small>
                                             <strong class="media-heading text-primary">
                                                <div class="point point-danger point-lg"></div>
                                                Richa
                                             </strong>
                                             <p class="mb-sm">
                                                <small>Cras sit amet nibh libero, in gravida nulla. Nulla...</small>
                                             </p>
                                          </div>
                                       </div>
                                    </a>
                                    <a href="javascript:void(0);" class="list-group-item">
                                       <div class="media">
                                          <div class="pull-left">
                                             <img style="width: 48px; height: 48px;" src="./tables_files/05.jpg" alt="Image" class="media-object img-rounded">
                                          </div>
                                          <div class="media-body clearfix">
                                             <small class="pull-right">4h</small>
                                             <strong class="media-heading text-primary">
                                                <div class="point point-danger point-lg"></div>
                                                Robert
                                             </strong>
                                             <p class="mb-sm">
                                                <small>Cras sit amet nibh libero, in gravida nulla. Nulla...</small>
                                             </p>
                                          </div>
                                       </div>
                                    </a>
                                    <a href="javascript:void(0);" class="list-group-item">
                                       <div class="media">
                                          <div class="pull-left">
                                             <img style="width: 48px; height: 48px;" src="./tables_files/06.jpg" alt="Image" class="media-object img-rounded">
                                          </div>
                                          <div class="media-body clearfix">
                                             <small class="pull-right">4h</small>
                                             <strong class="media-heading text-primary">
                                                <div class="point point-danger point-lg"></div>
                                                Priya
                                             </strong>
                                             <p class="mb-sm">
                                                <small>Cras sit amet nibh libero, in gravida nulla. Nulla...</small>
                                             </p>
                                          </div>
                                       </div>
                                    </a>
                                 </div>
                                 <div class="slimScrollBar" style="background: rgb(0, 0, 0); width: 7px; position: absolute; top: 0px; opacity: 0.4; border-radius: 7px; z-index: 99; right: 1px; display: block;"></div>
                                 <div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div>
                              </div>
                           </div>
                        </li>
                        <li class="p">
                           <a href="javascript:void(0);" class="text-center">
                           <small class="text-primary">READ ALL</small>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li class="dropdown dropdown-list">
                     <a href="javascript:void(0);" data-toggle="dropdown" data-play="bounceIn" class="dropdown-toggle">
                        <em class="fa fa-bell"></em>
                        <div class="label label-info">120</div>
                     </a>
                     <ul class="dropdown-menu">
                        <li>
                           <div class="list-group">
                              <a href="javascript:void(0);" class="list-group-item">
                                 <div class="media">
                                    <div class="pull-left">
                                       <em class="fa fa-envelope-o fa-2x text-success"></em>
                                    </div>
                                    <div class="media-body clearfix">
                                       <div class="media-heading">Unread messages</div>
                                       <p class="m0">
                                          <small>You have 10 unread messages</small>
                                       </p>
                                    </div>
                                 </div>
                              </a>
                              <a href="javascript:void(0);" class="list-group-item">
                                 <div class="media">
                                    <div class="pull-left">
                                       <em class="fa fa-cog fa-2x"></em>
                                    </div>
                                    <div class="media-body clearfix">
                                       <div class="media-heading">New settings</div>
                                       <p class="m0">
                                          <small>There are new settings available</small>
                                       </p>
                                    </div>
                                 </div>
                              </a>
                              <a href="javascript:void(0);" class="list-group-item">
                                 <div class="media">
                                    <div class="pull-left">
                                       <em class="fa fa-fire fa-2x"></em>
                                    </div>
                                    <div class="media-body clearfix">
                                       <div class="media-heading">Updates</div>
                                       <p class="m0">
                                          <small>There are
                                          <span class="text-primary">2</span>new updates available</small>
                                       </p>
                                    </div>
                                 </div>
                              </a>
                              <a href="javascript:void(0);" class="list-group-item">
                              <small>Unread notifications</small>
                              <span class="badge">14</span>
                              </a>
                           </div>
                        </li>
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a href="javascript:void(0);" data-toggle="dropdown" data-play="bounceIn" class="dropdown-toggle">
                     <em class="fa fa-user"></em>
                     </a>
                     <ul class="dropdown-menu">
                        <li>
                           <div class="p">
                              <p>Overall progress</p>
                              <div class="progress progress-striped progress-xs m0">
                                 <div role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%;" class="progress-bar progress-bar-success">
                                    <span class="sr-only">80% Complete</span>
                                 </div>
                              </div>
                           </div>
                        </li>
                        <li class="divider"></li>
                        <li><a href="javascript:void(0);">Profile</a></li>
                        <li><a href="javascript:void(0);">Settings</a></li>
                        <li>
                           <a href="javascript:void(0);">
                              Notifications
                              <div class="label label-info pull-right">5</div>
                           </a>
                        </li>
                        <li>
                           <a href="javascript:void(0);">
                              Messages
                              <div class="label label-danger pull-right">10</div>
                           </a>
                        </li>
                        <li><a href="javascript:void(0);">Logout</a></li>
                     </ul>
                  </li>
                  <li>
                     <a href="javascript:void(0);" data-toggle="offsidebar">
                     <em class="fa fa-align-right"></em>
                     </a>
                  </li>
               </ul>
            </div>
            <form role="search" class="navbar-form">
               <div class="form-group has-feedback">
                  <input type="text" placeholder="Type and hit Enter.." class="form-control">
                  <div data-toggle="navbar-search-dismiss" class="fa fa-times form-control-feedback"></div>
               </div>
               <button type="submit" class="hidden btn btn-default">Submit</button>
            </form>
         </nav>
         <aside class="aside">
            <nav class="sidebar">
               <ul class="nav">
                  <li>
                     <div data-toggle="collapse-next" class="item user-block has-submenu">
                        <div class="user-block-picture">
                           <img src="./tables_files/02.jpg" alt="Avatar" width="60" height="60" class="img-thumbnail img-circle">
                           <div class="user-block-status">
                              <div class="point point-success point-lg"></div>
                           </div>
                        </div>
                        <div class="user-block-info">
                           <span class="user-block-name item-text">Welcome, Priya</span>
                           <span class="user-block-role">Designer</span>
                           <div class="btn-group user-block-status">
                              <button type="button" data-toggle="dropdown" data-play="fadeIn" data-duration="0.2" class="btn btn-xs dropdown-toggle">
                                 <div class="point point-success"></div>
                                 Online
                              </button>
                              <ul class="dropdown-menu text-left pull-right">
                                 <li>
                                    <a href="javascript:void(0);">
                                       <div class="point point-success"></div>
                                       Online
                                    </a>
                                 </li>
                                 <li>
                                    <a href="javascript:void(0);">
                                       <div class="point point-warning"></div>
                                       Away
                                    </a>
                                 </li>
                                 <li>
                                    <a href="javascript:void(0);">
                                       <div class="point point-danger"></div>
                                       Busy
                                    </a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <ul class="nav collapse">
                        <li><a href="javascript:void(0);">Profile</a></li>
                        <li><a href="javascript:void(0);">Settings</a></li>
                        <li>
                           <a href="javascript:void(0);">
                              Notifications
                              <div class="label label-danger pull-right">120</div>
                           </a>
                        </li>
                        <li>
                           <a href="javascript:void(0);">
                              Messages
                              <div class="label label-success pull-right">300</div>
                           </a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="javascript:void(0);">Logout</a></li>
                     </ul>
                  </li>
                  <li>
                     <a href="http://letdiscuss.com/admin/index.html" title="Dashboard" data-toggle="collapse-next" class="has-submenu">
                        <em class="fa fa-dashboard"></em>
                        <div class="label label-primary pull-right">12</div>
                        <span class="item-text">Dashboard</span>
                     </a>
                     <ul class="nav collapse ">
                        <li>
                           <a href="http://letdiscuss.com/admin/index.html" title="Default" data-toggle="" class="no-submenu">
                           <span class="item-text">Default</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/dashboard-nosidebar.html" title="No Sidebar" data-toggle="" class="no-submenu">
                           <span class="item-text">No Sidebar</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/dashboard-noprofile.html" title="No Profile" data-toggle="" class="no-submenu">
                           <span class="item-text">No Profile</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li class="">
                     <a href="http://letdiscuss.com/admin/mail-inbox.html" title="Dashboard" class="">
                        <em class="fa fa-envelope-o"></em>
                        <div class="label label-primary pull-right">New</div>
                        <span class="item-text">Inbox</span>
                     </a>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="Charts" data-toggle="collapse-next" class="has-submenu">
                     <em class="fa fa-bar-chart-o"></em>
                     <span class="item-text">Charts</span>
                     </a>
                     <ul class="nav collapse ">
                        <li>
                           <a href="http://letdiscuss.com/admin/chart-flot.html" title="Flot" data-toggle="" class="no-submenu">
                           <span class="item-text">Flot</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/chart-radial.html" title="Radial" data-toggle="" class="no-submenu">
                           <span class="item-text">Radial</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li class="active">
                     <a href="javascript:void(0);" title="Tables" data-toggle="collapse-next" class="has-submenu">
                     <em class="fa fa-table"></em>
                     <span class="item-text">Tables</span>
                     </a>
                     <ul class="nav collapse in">
                        <li class="active">
                           <a href="http://letdiscuss.com/admin/table-datatable.html" title="Data Table" data-toggle="" class="no-submenu">
                           <span class="item-text">Data Table</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/table-standard.html" title="Standard" data-toggle="" class="no-submenu">
                           <span class="item-text">Standard</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/table-extended.html" title="Extended" data-toggle="" class="no-submenu">
                           <span class="item-text">Extended</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="Forms" data-toggle="collapse-next" class="has-submenu">
                     <em class="fa fa-edit"></em>
                     <span class="item-text">Forms</span>
                     </a>
                     <ul class="nav collapse ">
                        <li>
                           <a href="http://letdiscuss.com/admin/form-standard.html" title="Standard" data-toggle="" class="no-submenu">
                           <span class="item-text">Standard</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/form-extended.html" title="Extended" data-toggle="" class="no-submenu">
                           <span class="item-text">Extended</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/form-validation.html" title="Validation" data-toggle="" class="no-submenu">
                           <span class="item-text">Validation</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="Elements" data-toggle="collapse-next" class="has-submenu">
                     <em class="fa fa-wrench"></em>
                     <span class="item-text">Elements</span>
                     </a>
                     <ul class="nav collapse ">
                        <li>
                           <a href="http://letdiscuss.com/admin/panels.html" title="Panels" data-toggle="" class="no-submenu">
                           <span class="item-text">Panels</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/portlets.html" title="Portlets" data-toggle="" class="no-submenu">
                           <span class="item-text">Portlets</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/button.html" title="Buttons" data-toggle="" class="no-submenu">
                           <span class="item-text">Buttons</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/icons.html" title="Icons" data-toggle="" class="no-submenu">
                              <div class="label label-primary pull-right">+400</div>
                              <span class="item-text">Icons</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/notifications.html" title="Notifications" data-toggle="" class="no-submenu">
                           <span class="item-text">Notifications</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/typo.html" title="Typography" data-toggle="" class="no-submenu">
                           <span class="item-text">Typography</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/grid.html" title="Grid" data-toggle="" class="no-submenu">
                           <span class="item-text">Grid</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/grid-masonry.html" title="Grid Masonry" data-toggle="" class="no-submenu">
                           <span class="item-text">Grid Masonry</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/animations.html" title="Animations" data-toggle="" class="no-submenu">
                           <span class="item-text">Animations</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/dropdown-animations.html" title="Dropdown" data-toggle="" class="no-submenu">
                           <span class="item-text">Dropdown</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/widgets.html" title="Widgets" data-toggle="" class="no-submenu">
                           <span class="item-text">Widgets</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/maps.html" title="Maps" data-toggle="" class="no-submenu">
                           <span class="item-text">Maps</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/calendar.html" title="Calendar" data-toggle="" class="no-submenu">
                           <span class="item-text">Calendar</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/spinners.html" title="Spinners" data-toggle="" class="no-submenu">
                           <span class="item-text">Spinners</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="Pages" data-toggle="collapse-next" class="has-submenu">
                     <em class="fa fa-file-text"></em>
                     <span class="item-text">Pages</span>
                     </a>
                     <ul class="nav collapse ">
                        <li>
                           <a href="http://letdiscuss.com/admin/pages/login.html" title="Login" data-toggle="" class="no-submenu">
                           <span class="item-text">Login</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/pages/login-multi.html" title="Login Multi" data-toggle="" class="no-submenu">
                           <span class="item-text">Login Multi</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/pages/signup.html" title="Sign up" data-toggle="" class="no-submenu">
                           <span class="item-text">Sign up</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/pages/lock.html" title="Lock" data-toggle="" class="no-submenu">
                           <span class="item-text">Lock</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/pages/recover.html" title="Recover Password" data-toggle="" class="no-submenu">
                           <span class="item-text">Recover Password</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/template.html" title="Empty Template" data-toggle="" class="no-submenu">
                           <span class="item-text">Empty Template</span>
                           </a>
                        </li>
                        <li>
                           <a href="http://letdiscuss.com/admin/timeline.html" title="Timeline" data-toggle="" class="no-submenu">
                           <span class="item-text">Timeline</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li class="nav-footer">
                     <div class="nav-footer-divider"></div>
                     <div class="btn-group text-center">
                        <button type="button" data-toggle="tooltip" data-title="Add Contact" class="btn btn-link" data-original-title="" title="">
                        <em class="fa fa-user text-muted"><sup class="fa fa-plus"></sup>
                        </em>
                        </button>
                        <button type="button" data-toggle="tooltip" data-title="Settings" class="btn btn-link" data-original-title="" title="">
                        <em class="fa fa-cog text-muted"></em>
                        </button>
                        <button type="button" data-toggle="tooltip" data-title="Logout" class="btn btn-link" data-original-title="" title="">
                        <em class="fa fa-sign-out text-muted"></em>
                        </button>
                     </div>
                  </li>
               </ul>
            </nav>
         </aside>
         <aside class="offsidebar">
            <nav>
               <ul class="nav">
                  <li class="p">
                     <small class="text-muted">ONLINE</small>
                  </li>
                  <li>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-success point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="./tables_files/05.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">John Smith</strong>
                     <br>
                     <small class="text-muted">smithjohn</small>
                     </span>
                     </span>
                     </a>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-success point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="./tables_files/06.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">Richa</strong>
                     <br>
                     <small class="text-muted">richa</small>
                     </span>
                     </span>
                     </a>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-danger point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="./tables_files/07.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">Jarden</strong>
                     <br>
                     <small class="text-muted">jarden</small>
                     </span>
                     </span>
                     </a>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-warning point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="./tables_files/08.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">Smith</strong>
                     <br>
                     <small class="text-muted">smith</small>
                     </span>
                     </span>
                     </a>
                  </li>
                  <li class="p">
                     <small class="text-muted">OFFLINE</small>
                  </li>
                  <li>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="./tables_files/09.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">Mohes</strong>
                     <br>
                     <small class="text-muted">mohes</small>
                     </span>
                     </span>
                     </a>
                     <a href="javascript:void(0);" class="media p mt0">
                     <span class="pull-right">
                     <span class="point point-lg"></span>
                     </span>
                     <span class="pull-left">
                     <img src="./tables_files/10.jpg" style="width: 40px; height: 40px" alt="Image" class="media-object img-circle">
                     </span>
                     <span class="media-body">
                     <span class="media-heading">
                     <strong class="text-white">Mic</strong>
                     <br>
                     <small class="text-muted">mic</small>
                     </span>
                     </span>
                     </a>
                  </li>
                  <li>
                     <a href="javascript:void(0);" title="See more contacts" class="p">
                     <strong>
                     <small class="text-muted">…</small>
                     </strong>
                     </a>
                  </li>
               </ul>
            </nav>
         </aside>
         <section>
            <section class="main-content">
               <h3>Data Tables
                  <br>
                  <small>Tables, one step forward.</small>
               </h3>
               <div class="row">
                  <div class="col-lg-12">
                     <div class="panel panel-default">
                        <div class="panel-heading">Data Tables |
                           <small>Zero Configuration</small>
                        </div>
                        <div class="panel-body">
                           <div id="datatable1_wrapper" class="dataTables_wrapper form-inline no-footer">
                              <div class="row">
                                 <div class="col-xs-6">
                                    <div class="dataTables_length" id="datatable1_length">
                                       <label>
                                          <select name="datatable1_length" aria-controls="datatable1" class="form-control input-sm">
                                             <option value="10">10</option>
                                             <option value="25">25</option>
                                             <option value="50">50</option>
                                             <option value="100">100</option>
                                          </select>
                                          records per page
                                       </label>
                                    </div>
                                 </div>
                                 <div class="col-xs-6">
                                    <div id="datatable1_filter" class="dataTables_filter"><label>Search all columns:<input type="search" class="form-control input-sm" aria-controls="datatable1"></label></div>
                                 </div>
                              </div>
                              <table id="datatable1" class="table table-striped table-hover dataTable no-footer" role="grid" aria-describedby="datatable1_info">
                                 <thead>
                                    <tr role="row">
                                       <th class="sorting_asc" tabindex="0" aria-controls="datatable1" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column ascending" style="width: 171px;">Rendering engine</th>
                                       <th class="sorting" tabindex="0" aria-controls="datatable1" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 258px;">Browser</th>
                                       <th class="sorting" tabindex="0" aria-controls="datatable1" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending" style="width: 242px;">Platform(s)</th>
                                       <th class="sort-numeric sorting" tabindex="0" aria-controls="datatable1" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending" style="width: 144px;">Engine version</th>
                                       <th class="sort-alpha sorting" tabindex="0" aria-controls="datatable1" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending" style="width: 103px;">CSS grade</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 1.0</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.7</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 1.5</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 2.0</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 3.0</td>
                                       <td>Win 2k+ / OSX.3+</td>
                                       <td>1.9</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Camino 1.0</td>
                                       <td>OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Camino 1.5</td>
                                       <td>OSX.3+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Netscape 7.2</td>
                                       <td>Win 95+ / Mac OS 8.6-9.2</td>
                                       <td>1.7</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Netscape Browser 8</td>
                                       <td>Win 98SE+</td>
                                       <td>1.7</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Netscape Navigator 9</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Mozilla 1.0</td>
                                       <td>Win 95+ / OSX.1+</td>
                                       <td>1</td>
                                       <td>A</td>
                                    </tr>
                                 </tbody>
                              </table>
                              <div class="row">
                                 <div class="col-xs-6">
                                    <div class="dataTables_info" id="datatable1_info" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div>
                                 </div>
                                 <div class="col-xs-6">
                                    <div class="dataTables_paginate paging_simple_numbers" id="datatable1_paginate">
                                       <ul class="pagination">
                                          <li class="paginate_button previous disabled" aria-controls="datatable1" tabindex="0" id="datatable1_previous"><a href="javascript:void(0);">Previous</a></li>
                                          <li class="paginate_button active" aria-controls="datatable1" tabindex="0"><a href="javascript:void(0);">1</a></li>
                                          <li class="paginate_button " aria-controls="datatable1" tabindex="0"><a href="javascript:void(0);">2</a></li>
                                          <li class="paginate_button " aria-controls="datatable1" tabindex="0"><a href="javascript:void(0);">3</a></li>
                                          <li class="paginate_button " aria-controls="datatable1" tabindex="0"><a href="javascript:void(0);">4</a></li>
                                          <li class="paginate_button " aria-controls="datatable1" tabindex="0"><a href="javascript:void(0);">5</a></li>
                                          <li class="paginate_button " aria-controls="datatable1" tabindex="0"><a href="javascript:void(0);">6</a></li>
                                          <li class="paginate_button next" aria-controls="datatable1" tabindex="0" id="datatable1_next"><a href="javascript:void(0);">Next</a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-lg-12">
                     <div class="panel panel-default">
                        <div class="panel-heading">Data Tables |
                           <small>Column Ordering</small>
                        </div>
                        <div class="panel-body">
                           <div id="datatable2_wrapper" class="dataTables_wrapper form-inline">
                              <div class="row">
                                 <div class="col-xs-6">
                                    <div class="dataTables_length" id="datatable2_length">
                                       <label>
                                          <select name="datatable2_length" aria-controls="datatable2" class="form-control input-sm">
                                             <option value="10">10</option>
                                             <option value="25">25</option>
                                             <option value="50">50</option>
                                             <option value="100">100</option>
                                          </select>
                                          records per page
                                       </label>
                                    </div>
                                 </div>
                                 <div class="col-xs-6">
                                    <div id="datatable2_filter" class="dataTables_filter"><label>Search all columns:<input type="search" class="form-control input-sm" aria-controls="datatable2"></label></div>
                                 </div>
                              </div>
                              <table id="datatable2" class="table table-striped table-hover dataTable" role="grid" aria-describedby="datatable2_info">
                                 <thead>
                                    <tr role="row">
                                       <th class="sorting_asc" tabindex="0" aria-controls="datatable2" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column ascending" style="width: 181px;">Rendering engine</th>
                                       <th class="sorting" tabindex="0" aria-controls="datatable2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 191px;">Browser</th>
                                       <th class="sorting" tabindex="0" aria-controls="datatable2" rowspan="1" colspan="1" aria-label="Platform: activate to sort column ascending" style="width: 182px;">Platform</th>
                                       <th class="sort-numeric sorting" tabindex="0" aria-controls="datatable2" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending" style="width: 182px;">Engine version</th>
                                       <th class="sort-alpha sorting" tabindex="0" aria-controls="datatable2" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending" style="width: 182px;">CSS grade</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 1.0</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.7</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 1.5</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 2.0</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 3.0</td>
                                       <td>Win 2k+ / OSX.3+</td>
                                       <td>1.9</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Camino 1.0</td>
                                       <td>OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Camino 1.5</td>
                                       <td>OSX.3+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Netscape 7.2</td>
                                       <td>Win 95+ / Mac OS 8.6-9.2</td>
                                       <td>1.7</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Netscape Browser 8</td>
                                       <td>Win 98SE+</td>
                                       <td>1.7</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Netscape Navigator 9</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Mozilla 1.0</td>
                                       <td>Win 95+ / OSX.1+</td>
                                       <td>1</td>
                                       <td>A</td>
                                    </tr>
                                 </tbody>
                                 <tfoot>
                                    <tr>
                                       <th rowspan="1" colspan="1">
                                          <input type="text" name="filter_rendering_engine" placeholder="Filter Rendering engine" class="form-control input-sm datatable_input_col_search">
                                       </th>
                                       <th rowspan="1" colspan="1">
                                          <input type="text" name="filter_browser" placeholder="Filter Browser" class="form-control input-sm datatable_input_col_search">
                                       </th>
                                       <th rowspan="1" colspan="1">
                                          <input type="text" name="filter_platform" placeholder="Filter Platform" class="form-control input-sm datatable_input_col_search">
                                       </th>
                                       <th rowspan="1" colspan="1">
                                          <input type="text" name="filter_engine_version" placeholder="Filter Engine version" class="form-control input-sm datatable_input_col_search">
                                       </th>
                                       <th rowspan="1" colspan="1">
                                          <input type="text" name="filter_css_grade" placeholder="Filter CSS grade" class="form-control input-sm datatable_input_col_search">
                                       </th>
                                    </tr>
                                 </tfoot>
                              </table>
                              <div class="row">
                                 <div class="col-xs-6">
                                    <div class="dataTables_info" id="datatable2_info" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div>
                                 </div>
                                 <div class="col-xs-6">
                                    <div class="dataTables_paginate paging_simple_numbers" id="datatable2_paginate">
                                       <ul class="pagination">
                                          <li class="paginate_button previous disabled" aria-controls="datatable2" tabindex="0" id="datatable2_previous"><a href="javascript:void(0);">Previous</a></li>
                                          <li class="paginate_button active" aria-controls="datatable2" tabindex="0"><a href="javascript:void(0);">1</a></li>
                                          <li class="paginate_button " aria-controls="datatable2" tabindex="0"><a href="javascript:void(0);">2</a></li>
                                          <li class="paginate_button " aria-controls="datatable2" tabindex="0"><a href="javascript:void(0);">3</a></li>
                                          <li class="paginate_button " aria-controls="datatable2" tabindex="0"><a href="javascript:void(0);">4</a></li>
                                          <li class="paginate_button " aria-controls="datatable2" tabindex="0"><a href="javascript:void(0);">5</a></li>
                                          <li class="paginate_button " aria-controls="datatable2" tabindex="0"><a href="javascript:void(0);">6</a></li>
                                          <li class="paginate_button next" aria-controls="datatable2" tabindex="0" id="datatable2_next"><a href="javascript:void(0);">Next</a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-lg-12">
                     <div class="panel panel-default">
                        <div class="panel-heading">Data Tables |
                           <small>Column Visibility</small>
                        </div>
                        <div class="panel-body">
                           <div style="padding-bottom: 10px;">
                              <b>Toggle column:</b> <a class="toggle-vis btn btn-info btn-secondary" href="javascript:void(0);" data-col="0">Rendering engine</a> - <a class="toggle-vis btn btn-info btn-secondary" href="javascript:void(0);" data-col="1">Browser</a> - <a class="toggle-vis btn btn-info btn-secondary" href="javascript:void(0);" data-col="2">Platform</a> - <a class="toggle-vis btn btn-info btn-secondary" href="javascript:void(0);" data-col="3">Engine Version</a> - <a class="toggle-vis btn btn-info btn-secondary" href="javascript:void(4);" data-col="4">CSS Grade</a>
                           </div>
                           <div id="datatable3_wrapper" class="dataTables_wrapper form-inline">
                              <div class="row">
                                 <div class="col-xs-6">
                                    <div class="dataTables_length" id="datatable3_length">
                                       <label>
                                          <select name="datatable3_length" aria-controls="datatable3" class="form-control input-sm">
                                             <option value="10">10</option>
                                             <option value="25">25</option>
                                             <option value="50">50</option>
                                             <option value="100">100</option>
                                          </select>
                                          records per page
                                       </label>
                                    </div>
                                 </div>
                                 <div class="col-xs-6">
                                    <div id="datatable3_filter" class="dataTables_filter"><label>Search all columns:<input type="search" class="form-control input-sm" aria-controls="datatable3"></label></div>
                                 </div>
                              </div>
                              <table id="datatable3" class="table table-striped table-hover dataTable" role="grid" aria-describedby="datatable3_info">
                                 <thead>
                                    <tr role="row">
                                       <th class="sorting_asc" tabindex="0" aria-controls="datatable3" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column ascending" style="width: 171px;">Rendering engine</th>
                                       <th class="sorting" tabindex="0" aria-controls="datatable3" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending" style="width: 258px;">Browser</th>
                                       <th class="sorting" tabindex="0" aria-controls="datatable3" rowspan="1" colspan="1" aria-label="Platform: activate to sort column ascending" style="width: 242px;">Platform</th>
                                       <th class="sort-numeric sorting" tabindex="0" aria-controls="datatable3" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending" style="width: 144px;">Engine version</th>
                                       <th class="sort-alpha sorting" tabindex="0" aria-controls="datatable3" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending" style="width: 103px;">CSS grade</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 1.0</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.7</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 1.5</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 2.0</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Firefox 3.0</td>
                                       <td>Win 2k+ / OSX.3+</td>
                                       <td>1.9</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Camino 1.0</td>
                                       <td>OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Camino 1.5</td>
                                       <td>OSX.3+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Netscape 7.2</td>
                                       <td>Win 95+ / Mac OS 8.6-9.2</td>
                                       <td>1.7</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Netscape Browser 8</td>
                                       <td>Win 98SE+</td>
                                       <td>1.7</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA odd" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Netscape Navigator 9</td>
                                       <td>Win 98+ / OSX.2+</td>
                                       <td>1.8</td>
                                       <td>A</td>
                                    </tr>
                                    <tr class="gradeA even" role="row">
                                       <td class="sorting_1">Gecko</td>
                                       <td>Mozilla 1.0</td>
                                       <td>Win 95+ / OSX.1+</td>
                                       <td>1</td>
                                       <td>A</td>
                                    </tr>
                                 </tbody>
                                 <tfoot>
                                    <tr>
                                       <th rowspan="1" colspan="1">Rendering engine</th>
                                       <th rowspan="1" colspan="1">Browser</th>
                                       <th rowspan="1" colspan="1">Platform</th>
                                       <th rowspan="1" colspan="1">Engine version</th>
                                       <th rowspan="1" colspan="1">CSS grade</th>
                                    </tr>
                                 </tfoot>
                              </table>
                              <div class="row">
                                 <div class="col-xs-6">
                                    <div class="dataTables_info" id="datatable3_info" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div>
                                 </div>
                                 <div class="col-xs-6">
                                    <div class="dataTables_paginate paging_simple_numbers" id="datatable3_paginate">
                                       <ul class="pagination">
                                          <li class="paginate_button previous disabled" aria-controls="datatable3" tabindex="0" id="datatable3_previous"><a href="javascript:void(0);">Previous</a></li>
                                          <li class="paginate_button active" aria-controls="datatable3" tabindex="0"><a href="javascript:void(0);">1</a></li>
                                          <li class="paginate_button " aria-controls="datatable3" tabindex="0"><a href="javascript:void(0);">2</a></li>
                                          <li class="paginate_button " aria-controls="datatable3" tabindex="0"><a href="javascript:void(0);">3</a></li>
                                          <li class="paginate_button " aria-controls="datatable3" tabindex="0"><a href="javascript:void(0);">4</a></li>
                                          <li class="paginate_button " aria-controls="datatable3" tabindex="0"><a href="javascript:void(0);">5</a></li>
                                          <li class="paginate_button " aria-controls="datatable3" tabindex="0"><a href="javascript:void(0);">6</a></li>
                                          <li class="paginate_button next" aria-controls="datatable3" tabindex="0" id="datatable3_next"><a href="javascript:void(0);">Next</a></li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         </section>
      </section>
      <script src="../js/jquery.min.js"></script>
      <script src="../js/bootstrap.min.js"></script>
      <script src="../js/chosen.jquery.min.js"></script>
      <script src="../js/bootstrap-slider.js"></script>
      <script src="../js/bootstrap-filestyle.min.js"></script>
      <script src="../js/animo.min.js"></script>
      <script src="../js/jquery.sparkline.min.js"></script>
      <script src="../js/jquery.slimscroll.min.js"></script>
      <script src="../js/jquery.dataTables.min.js"></script>
      <script src="../js/dataTables.bootstrap.js"></script>
      <script src="../js/dataTables.bootstrapPagination.js"></script>
      <script src="../js/dataTables.colVis.min.js"></script>
      <script src="../js/app.js"></script>
   </body>
</html>