<aside class="aside">
	<nav class="sidebar">
		<ul class="nav">
			<li onclick="setState(STATE_SHOPS)">
				<a href="javascript:void(0)" title="Dashboard">
					<em class="fa fa-envelope-o"></em>
					<!--<div class="label label-primary pull-right">New</div>-->
					<span class="item-text">Магазины</span>
				</a>
			</li>
		</ul>
	</nav>
 </aside>